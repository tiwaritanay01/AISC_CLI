# Experiment 02: Informed Search - A* Algorithm for 15-Puzzle Problem

## Aim
Informed Search - A* Algorithm for the 15-Puzzle Problem using Manhattan Distance heuristic.

## Description
Heuristic A* search algorithm using Manhattan Distance to solve the 15-Puzzle problem.

## Theory
The A* algorithm is an informed search strategy used to find the shortest path between nodes in a state-space graph.
It evaluates nodes using f(n) = g(n) + h(n), where g(n) is the exact cost to reach node n from the start, and h(n) is an admissible heuristic estimating the cost from n to the goal.
For the 15-puzzle problem, the sum of Manhattan distances of all tiles to their goal coordinates provides an admissible and consistent heuristic.
