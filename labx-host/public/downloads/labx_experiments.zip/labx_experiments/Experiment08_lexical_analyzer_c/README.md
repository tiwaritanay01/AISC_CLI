# Experiment 08: Lexical Analyzer for Arithmetic Expressions

## Aim
To construct a lexical analyzer in C to identify keywords, identifiers, constants, and operators.

## Description
Deterministic finite automaton (DFA) based lexical analyzer tokenizing source input in C.

## Theory
Lexical analysis is the first phase of a compiler.
It scans source characters into meaningful sequences called lexemes and produces corresponding tokens: <TOKEN_TYPE, VALUE> for subsequent syntax analysis.
