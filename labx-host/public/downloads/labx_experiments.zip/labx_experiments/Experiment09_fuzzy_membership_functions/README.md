# Experiment 09: Implementation of Fuzzy Membership Functions

## Aim
To implement fuzzy membership functions (Triangular and Trapezoidal) and calculate degrees of membership for inputs.

## Description
Mathematical implementation and evaluation of Triangular and Trapezoidal fuzzy membership functions.

## Theory
Unlike classical binary sets where elements have strict membership (0 or 1), fuzzy sets assign elements a continuous degree of membership between [0, 1].
Triangular Membership Function: defined by lower limit a, peak b, and upper limit c.
Trapezoidal Membership Function: defined by lower limit a, plateau span [b, c], and upper limit d.
