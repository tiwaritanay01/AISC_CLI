# Experiment 04: Dijkstra's Shortest Path Routing Algorithm

## Aim
To implement Dijkstra's shortest path algorithm in C++ for network link-state routing simulation.

## Description
Simulation of dynamic routing and shortest path calculation in packet networks using Dijkstra's algorithm.

## Theory
Dijkstra's algorithm is an algorithm for finding the shortest paths between nodes in a weighted graph.
In computer networking, it forms the foundation of Link State routing protocols such as Open Shortest Path First (OSPF).
Each router maintains a complete topology map and computes the shortest path tree from itself as the root to all other nodes.
