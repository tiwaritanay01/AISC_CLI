# Experiment 01: Case Study on AI Agents & PEAS Properties

## Aim
To prepare a case study on AI Agents including type, environment, and PEAS properties.

## Description
Comprehensive study and simulation of AI Agent types (Simple Reflex, Model, Goal, Utility) and PEAS properties.

## Theory
AI Agents can be classified into four primary types: Simple Reflex, Model-Based, Goal-Based, and Utility-Based.
The environment can be categorized across dimensions: fully vs. partially observable, deterministic vs. stochastic, static vs. dynamic, and episodic vs. sequential.
The PEAS framework defines: Performance measure, Environment, Actuators, and Sensors, formalizing the agent's interaction loop.
