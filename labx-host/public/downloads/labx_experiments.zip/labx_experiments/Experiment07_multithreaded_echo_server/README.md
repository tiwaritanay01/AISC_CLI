# Experiment 07: Multi-Threaded Echo Server in Java

## Aim
To implement a concurrent multi-threaded echo server using Java Runnable and Socket threads.

## Description
Concurrent multi-threaded TCP server handling multiple simultaneous client connections.

## Theory
A single-threaded server can only service one client at a time, leaving other connection requests blocked.
A multi-threaded server spawns a dedicated worker thread for each accepted client socket, enabling concurrent data processing.
