# Experiment 02: Matrix Multiplication & Transpose Operations

## Aim
To implement matrix multiplication and transpose in C using modular functions.

## Description
Multiplication, transposition, and dynamic memory operations on two-dimensional matrices in C.

## Theory
Matrix multiplication of matrix A (m x k) and B (k x n) yields matrix C (m x n), where each element C[i][j] is the dot product of row i of A and column j of B.
Matrix transposition flips a matrix over its diagonal, switching the row and column indices of the matrix.
