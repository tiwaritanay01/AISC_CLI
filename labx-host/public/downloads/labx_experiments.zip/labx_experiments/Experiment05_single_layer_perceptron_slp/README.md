# Experiment 05: Single Layer Perceptron (SLP) for Binary Classification

## Aim
To implement a Single Layer Perceptron (SLP) neural network using the Perceptron Learning Rule to classify linearly separable binary patterns.

## Description
Perceptron Learning Rule implementation to train a Single Layer Perceptron on linearly separable patterns.

## Theory
A Single Layer Perceptron is the fundamental unit of an artificial neural network.
It computes a linear combination of inputs weighted by parameter vector W plus bias b, passed through a step activation function.
The Perceptron Learning Rule updates weights iteratively: W = W + eta * (y - y_hat) * X, converging for linearly separable datasets.
