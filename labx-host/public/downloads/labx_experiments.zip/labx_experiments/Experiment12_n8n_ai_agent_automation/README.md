# Experiment 12: AI Agent for Automation using n8n Workflow Architecture

## Aim
To create an AI agent for automation using node-based workflow tools like n8n.

## Description
AI Agent automation framework simulating n8n node routing, LLM intent parsing, and automated tool triggering.

## Theory
n8n is an open, extensible node-based workflow automation tool connecting REST APIs and enterprise services.
An autonomous AI Agent in n8n routes natural language prompts through an LLM reasoning node.
The model output is parsed into structured parameters and dispatched to downstream nodes (e.g., Slack, Email, PostgreSQL, Notion) for autonomous multi-step execution.
