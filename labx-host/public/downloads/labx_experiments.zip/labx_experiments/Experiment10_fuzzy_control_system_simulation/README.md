# Experiment 10: Fuzzy Control System Simulation (Fan Speed Controller)

## Aim
To write a program to simulate a fuzzy logic control system for temperature-dependent fan speed control.

## Description
Simulation of a Mamdani fuzzy inference control system regulating fan speed based on room temperature.

## Theory
A Fuzzy Logic Controller operates in four stages:
1. Fuzzification: Translates crisp numeric sensor inputs into linguistic fuzzy variables (Cold, Warm, Hot).
2. Rule Base: IF-THEN conditional rules defining system dynamics.
3. Inference Engine: Evaluates active rules using fuzzy operators (e.g. Mamdani min/max).
4. Defuzzification: Computes a crisp output value (e.g. Centroid / Center of Gravity method).
