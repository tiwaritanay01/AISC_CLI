# Experiment 01: Factorial and Fibonacci Sequence Generator

## Aim
To write a Python program to calculate the factorial of a given number and generate the Fibonacci sequence up to N terms.

## Description
Computation of mathematical factorial and Fibonacci sequences using iterative and recursive techniques.

## Theory
The factorial of a non-negative integer n, denoted by n!, is the product of all positive integers less than or equal to n.
The Fibonacci sequence is a series of numbers where each number is the sum of the two preceding ones, usually starting with 0 and 1.
Both problems demonstrate recursion, stack frames, and memoization in computer science.
