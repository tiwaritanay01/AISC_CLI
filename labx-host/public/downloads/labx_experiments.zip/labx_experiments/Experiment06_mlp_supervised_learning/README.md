# Experiment 06: Supervised Learning using Multi-Layer Perceptron (MLP)

## Aim
To implement the Supervised Learning algorithm using Multi-Layer Perceptron (MLP) with Backpropagation to solve non-linear problems (XOR).

## Description
Multi-Layer Perceptron neural network with sigmoid activations and gradient descent backpropagation.

## Theory
A Multi-Layer Perceptron (MLP) consists of an input layer, one or more hidden layers, and an output layer.
Because of non-linear activation functions (such as Sigmoid), an MLP is capable of learning non-linearly separable decision boundaries (e.g. XOR gate).
Training occurs via Backpropagation: forward pass computes loss, backward pass computes gradients using the chain rule and updates weights.
