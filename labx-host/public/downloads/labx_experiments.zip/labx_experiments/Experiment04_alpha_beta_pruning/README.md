# Experiment 04: Implementation of Alpha-Beta Pruning Algorithm

## Aim
To implement Minimax Search with Alpha-Beta Pruning for two-player adversarial games.

## Description
Adversarial search and branch pruning algorithm optimizing the minimax game-tree decision process.

## Theory
Alpha-Beta pruning is an optimization technique for the minimax algorithm.
It maintains two parameters: alpha (best value achieved by the maximizer so far) and beta (best value achieved by the minimizer so far).
Whenever alpha >= beta, the current branch is pruned because the opponent would never permit that line of play.
