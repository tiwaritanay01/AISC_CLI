# Experiment 03: Uninformed Search - Depth First Iterative Deepening (DFID)

## Aim
Uninformed Search - Depth First Iterative Deepening (DFID) search implementation on state graphs.

## Description
Depth First Iterative Deepening (DFID/IDDFS) graph search combining space efficiency of DFS with optimality of BFS.

## Theory
DFID (Depth First Iterative Deepening), also known as IDDFS, is an uninformed search strategy that repeatedly executes depth-limited searches with incrementally increasing depth limits until the goal state is located.
It combines the linear space complexity O(bd) of Depth-First Search with the completeness and optimality of Breadth-First Search.
