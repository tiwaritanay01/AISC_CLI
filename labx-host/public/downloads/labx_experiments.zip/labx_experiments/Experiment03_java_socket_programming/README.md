# Experiment 03: Java Socket Programming (Client-Server)

## Aim
To implement a client-server socket communication program using Java TCP Sockets.

## Description
Two-way client-server network communication using Java TCP Sockets and Stream I/O.

## Theory
A socket is an endpoint for communication between two machines over a network.
Java provides the java.net package, containing ServerSocket (listening on a port for inbound connections) and Socket (connecting to the server's IP address and port).
Data transfer occurs via BufferedReader and PrintWriter wrapping socket input/output streams.
