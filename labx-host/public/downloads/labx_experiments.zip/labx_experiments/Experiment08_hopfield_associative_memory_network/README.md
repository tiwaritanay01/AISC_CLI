# Experiment 08: Associative Memory Network (Hopfield Network)

## Aim
To implement an Associative Memory Network (Hopfield Network) for pattern storage and associative recall.

## Description
Discrete Hopfield Network using Hebbian learning for auto-associative memory and corrupted pattern restoration.

## Theory
A Hopfield Network is a recurrent artificial neural network that serves as a content-addressable associative memory system.
Neurons have binary/bipolar threshold states (-1, +1) and symmetrical synaptic connections with zero self-feedback (w_ii = 0).
Using Hebbian learning rules, patterns are stored as stable attractors (local energy minima). When presented with a noisy or incomplete input, the network iteratively converges to the stored prototype.
