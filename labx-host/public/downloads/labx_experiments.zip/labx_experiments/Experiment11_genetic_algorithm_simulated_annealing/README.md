# Experiment 11: Optimization using Genetic Algorithm & Simulated Annealing

## Aim
To implement Genetic Algorithm and Simulated Annealing metaheuristics for continuous optimization.

## Description
Population-based Genetic Algorithm and stochastic Simulated Annealing for non-linear function optimization.

## Theory
Genetic Algorithms (GA) mimic biological natural selection: candidate solutions (individuals) undergo selection, crossover (recombination), and mutation across successive generations to optimize a fitness objective.
Simulated Annealing (SA) mimics the thermodynamic process of metallurgical annealing: a single candidate is perturbed, and uphill moves are conditionally accepted with probability exp(-delta_E / T) allowing escape from local optima.
