# Experiment 09: Binary Search Tree Operations & Traversals

## Aim
To construct a Binary Search Tree (BST) and implement traversals (Inorder, Preorder, Postorder).

## Description
Insertion, searching, deletion, and in-order/pre-order traversals of a Binary Search Tree in C++.

## Theory
A Binary Search Tree is a binary tree data structure where each node has at most two children.
The key of each internal node is greater than all keys in its left subtree and less than all keys in its right subtree.
An inorder traversal of a BST yields keys in sorted ascending order.
