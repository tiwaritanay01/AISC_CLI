# Experiment 07: Unsupervised Learning using K-Means Clustering

## Aim
To implement the Unsupervised Learning algorithm using K-Means Clustering to group unlabelled sample points.

## Description
K-Means clustering algorithm partitioning unlabelled multidimensional data into optimal spatial clusters.

## Theory
K-Means is an unsupervised clustering algorithm that groups n observations into k clusters.
Each observation belongs to the cluster with the nearest mean (cluster centroid), which serves as a prototype of the cluster.
The objective is to minimize intra-cluster variance (Within-Cluster Sum of Squares, WCSS).
