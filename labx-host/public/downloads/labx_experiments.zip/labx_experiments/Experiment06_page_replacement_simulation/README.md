# Experiment 06: Page Replacement Simulation (FIFO & LRU)

## Aim
To write a Python simulation of FIFO and LRU page replacement policies and compare their page fault rates.

## Description
Simulation and performance comparison of FIFO and LRU virtual memory page replacement algorithms.

## Theory
Virtual memory uses paging to map virtual addresses to physical frames. When a requested page is not in memory, a page fault occurs.
FIFO (First-In, First-Out) replaces the oldest resident page in memory.
LRU (Least Recently Used) replaces the page that has not been referenced for the longest period of time.
