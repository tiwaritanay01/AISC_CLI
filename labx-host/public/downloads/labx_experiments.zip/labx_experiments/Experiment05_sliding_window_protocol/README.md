# Experiment 05: Sliding Window Flow Control Protocol (Go-Back-N)

## Aim
To simulate the sliding window protocol (Go-Back-N) for flow control in data link layers.

## Description
Simulation of the Go-Back-N sliding window flow control and error recovery protocol in C.

## Theory
The sliding window protocol is a method of flow control where the sender is allowed to transmit multiple frames before receiving an acknowledgment from the receiver.
In Go-Back-N ARQ, if a frame is corrupted or lost, the receiver discards all subsequent frames, and the sender retransmits all unacknowledged frames starting from the lost frame.
