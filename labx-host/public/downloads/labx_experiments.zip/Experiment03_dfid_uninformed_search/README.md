# Experiment 03: Uninformed Search - Depth First Iterative Deepening (DFID)

## Aim
Uninformed Search - Depth First Iterative Deepening (DFID) search implementation on state graphs.

## Description
Depth First Iterative Deepening (DFID/IDDFS) graph search combining space efficiency of DFS with optimality of BFS.

## Theory
Depth First Iterative Deepening is a search strategy that combines the benefits of Breadth First Search and Depth First Search. It works by performing a series of depth-first searches with increasing depth limits, starting from a small limit and gradually increasing it until the goal is found. The algorithm uses a stack to keep track of nodes to visit and their depths, and it backtracks when it reaches a node that exceeds the current depth limit. This approach allows DFID to find the shortest path to the goal while avoiding the high memory usage of Breadth First Search. The time complexity of DFID is O(b^d) and the space complexity is O(d), where b is the branching factor and d is the depth of the goal node.
