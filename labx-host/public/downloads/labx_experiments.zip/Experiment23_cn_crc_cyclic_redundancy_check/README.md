# Experiment 23: Experiment 6 – CRC (Cyclic Redundancy Check)

## Aim
To write a C program to implement Cyclic Redundancy Check (CRC) error detection technique.

## Description
Implementation of Cyclic Redundancy Check (CRC) error detection using modulo-2 polynomial division.

## Theory
CRC is an error-detecting code based on polynomial arithmetic modulo 2. The sender generates a codeword by appending remainder bits from dividing data bits by a predetermined generator polynomial. The receiver performs the same division; a non-zero remainder indicates transmission error.
