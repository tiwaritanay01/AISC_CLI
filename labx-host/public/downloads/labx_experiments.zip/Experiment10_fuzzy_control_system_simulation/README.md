# Experiment 10: Fuzzy Control System Simulation (Fan Speed Controller)

## Aim
To write a program to simulate a fuzzy logic control system for temperature-dependent fan speed control.

## Description
Simulation of a Mamdani fuzzy inference control system regulating fan speed based on room temperature.

## Theory
Fuzzy control systems use linguistic variables and membership functions to map crisp inputs to fuzzy sets. Rules are expressed in IF-THEN form, combining antecedents with AND/OR operators to produce fuzzy outputs. Defuzzification (e.g., centroid) converts the aggregated fuzzy output back to a crisp control action. The system handles uncertainty by allowing partial membership, enabling smoother transitions than binary logic.
