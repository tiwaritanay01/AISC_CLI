# Experiment 26: Experiment 9 – Client-Server Socket Programming in Java

## Aim
To write a client-server socket program using TCP in Java for two-way communication.

## Description
Two-way client-server socket communication implementation in Java using ServerSocket and Socket classes over TCP.

## Theory
A Network Socket is one endpoint of a two-way communication link between two programs over a computer network. The ServerSocket class binds to a local port and awaits client connections via accept(). The Socket class establishes connection to the server IP and port. Java streams (BufferedReader, PrintWriter) handle bidirectional character and data transmission.
