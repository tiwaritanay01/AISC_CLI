# Experiment 12: AI Agent for Automation using n8n Workflow Architecture

## Aim
To create an AI agent for automation using node-based workflow tools like n8n.

## Description
AI Agent automation framework simulating n8n node routing, LLM intent parsing, and automated tool triggering.

## Theory
n8n is a workflow automation tool that uses nodes to connect services via APIs. An AI agent can be built by creating a node that sends user input to an LLM (e.g., OpenAI) and processes the response. The workflow then routes the LLM output to subsequent nodes that perform actions like sending emails, updating databases, or triggering other APIs. By chaining these nodes, the agent can interpret natural language commands and execute complex automation tasks.
