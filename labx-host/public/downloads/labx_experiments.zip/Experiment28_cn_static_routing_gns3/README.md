# Experiment 28: Static Routing Configuration in GNS3 (Router & Host Setup)

## Aim
To configure and verify Static Routing between two Cisco routers connecting distinct subnets using GNS3.

## Description
Complete Cisco IOS and VPCS terminal configuration commands for setting up static routes across R1 and R2 routers in a GNS3 network topology.

## Theory
Static routing is a method where routes are manually programmed into a router's routing table using the 'ip route <destination-network> <subnet-mask> <next-hop-ip>' command. Unlike dynamic routing protocols, static routes do not incur bandwidth or CPU overhead and provide predictable deterministic packet paths. In this GNS3 topology (PC1 - Switch1 - R1 - R2 - Switch2 - PC2), R1 is configured with a static route to the 192.168.3.0/24 subnet via R2 (192.168.2.2), and R2 with a static route to the 192.168.1.0/24 subnet via R1 (192.168.2.1), enabling bidirectional ICMP echo ping communication.
