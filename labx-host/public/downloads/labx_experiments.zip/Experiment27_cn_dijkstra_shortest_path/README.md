# Experiment 27: Experiment 10 – Dijkstra's Shortest Path Routing Algorithm

## Aim
To implement Dijkstra's shortest path routing algorithm in C to find minimum cost routes in a computer network.

## Description
Implementation of Dijkstra's algorithm in C to compute single-source shortest path routing tables for Link State Routing (OSPF).

## Theory
Dijkstra's algorithm is a greedy algorithm used in Link-State routing protocols like OSPF and IS-IS to compute the Shortest Path Tree (SPT) from a single source router to all other network routers. Each router maintains a global link-state database (LSDB), and through edge relaxation, computes the optimal routing table.
