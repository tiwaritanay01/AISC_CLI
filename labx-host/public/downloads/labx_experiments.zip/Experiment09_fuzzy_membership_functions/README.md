# Experiment 09: Implementation of Fuzzy Membership Functions

## Aim
To implement fuzzy membership functions (Triangular and Trapezoidal) and calculate degrees of membership for inputs.

## Description
Mathematical implementation and evaluation of Triangular and Trapezoidal fuzzy membership functions.

## Theory
Fuzzy membership functions map crisp inputs to degrees of belonging between 0 and 1, enabling reasoning with imprecise data. Common shapes include triangular, trapezoidal, Gaussian, and sigmoid, each defined by a few parameters that control the width and center of the fuzzy set. The choice of shape affects smoothness, computational cost, and interpretability. Membership values are combined via fuzzy operators (AND, OR) and aggregated to produce fuzzy outputs, which are then defuzzified to crisp decisions. Proper tuning of parameters is essential for accurate modeling of real-world phenomena.
