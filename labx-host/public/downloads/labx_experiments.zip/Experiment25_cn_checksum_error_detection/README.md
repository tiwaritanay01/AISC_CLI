# Experiment 25: Experiment 8 – Checksum Error Detection

## Aim
To write a C program to implement Checksum error detection using one's complement addition.

## Description
Implementation of Internet Checksum algorithm using 8-bit one's complement arithmetic and end-around carry.

## Theory
The checksum algorithm partitions data into equal k-bit words and sums them using one's complement arithmetic with end-around carry. The sender transmits the bitwise complement as the checksum. The receiver sums data words plus checksum; a total equal to all 1s confirms error-free transmission.
