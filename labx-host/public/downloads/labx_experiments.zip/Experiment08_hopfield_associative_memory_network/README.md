# Experiment 08: Associative Memory Network (Hopfield Network)

## Aim
To implement an Associative Memory Network (Hopfield Network) for pattern storage and associative recall.

## Description
Discrete Hopfield Network using Hebbian learning for auto-associative memory and corrupted pattern restoration.

## Theory
Associative memory stores patterns as high-dimensional vectors and retrieves them by similarity. The classic Hopfield network uses a symmetric weight matrix built from outer products of stored patterns, and updates neurons asynchronously until convergence. Retrieval works by presenting a noisy or incomplete pattern, then iteratively applying the sign of the weighted sum until the state stabilizes to the nearest stored pattern. TODO: compute weight matrix W = Σ_i p_i p_iᵀ - N·I, then iterate v ← sign(Wv) until convergence.
