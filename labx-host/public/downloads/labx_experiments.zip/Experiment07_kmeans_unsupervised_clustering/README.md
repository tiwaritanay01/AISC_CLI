# Experiment 07: Unsupervised Learning using K-Means Clustering

## Aim
To implement the Unsupervised Learning algorithm using K-Means Clustering to group unlabelled sample points.

## Description
K-Means clustering algorithm partitioning unlabelled multidimensional data into optimal spatial clusters.

## Theory
Unsupervised learning finds structure in data without labels, using methods like clustering to group similar items and dimensionality reduction to uncover latent factors. Techniques such as k-means, DBSCAN, hierarchical clustering, PCA, t-SNE, and autoencoders help reveal patterns, anomalies, or low-dimensional representations. The goal is to extract insights, compress data, or prepare features for downstream tasks.
