# Experiment 29: Dynamic Routing Configuration using RIP v2 in GNS3

## Aim
To configure and verify Dynamic Routing using RIP version 2 between two Cisco routers connecting distinct subnets using GNS3.

## Description
Complete Cisco IOS and VPCS terminal configuration commands for activating Dynamic Routing Information Protocol (RIP v2) across routers R1 and R2 with classless routing in GNS3.

## Theory
Routing Information Protocol (RIP) is an Interior Gateway Protocol (IGP) based on the Bellman-Ford Distance-Vector routing algorithm. RIP uses hop count as its primary routing metric (maximum 15 hops, 16 is unreachable). RIP version 2 improves upon RIP v1 by supporting classless inter-domain routing (CIDR), Variable Length Subnet Masking (VLSM) via 'no auto-summary', route summarization, and multicast updates (224.0.0.9). In this topology, routers R1 and R2 dynamically advertise directly connected subnets, compute optimal routing tables with periodic update timers (30 seconds), and converge to enable end-to-end ICMP ping traffic.
