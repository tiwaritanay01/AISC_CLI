# Experiment 11: Optimization using Genetic Algorithm & Simulated Annealing

## Aim
To implement Genetic Algorithm and Simulated Annealing metaheuristics for continuous optimization.

## Description
Population-based Genetic Algorithm and stochastic Simulated Annealing for non-linear function optimization.

## Theory
Genetic algorithms mimic biological evolution: a population of candidate solutions is evolved through selection, crossover, and mutation to optimize a fitness function. Simulated annealing mimics physical annealing: a single solution is iteratively perturbed and accepted with a probability that decreases with temperature, allowing escape from local optima. Both methods rely on stochastic search and balance exploration with exploitation. Key parameters: population size, crossover/mutation rates for GA; cooling schedule and acceptance probability for SA.
