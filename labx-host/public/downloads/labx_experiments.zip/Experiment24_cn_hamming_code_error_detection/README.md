# Experiment 24: Experiment 7 – Hamming Code Error Detection & Correction

## Aim
To write a C program to implement Hamming Code for error detection and correction of data bits.

## Description
Implementation of Hamming Code for single-bit error detection and automatic bit correction.

## Theory
Hamming code adds redundant parity bits at power-of-two positions (1, 2, 4, 8, ...). By evaluating parity checks across specific bit subsets, the receiver calculates an error syndrome whose binary value pinpoints the exact corrupted bit position for correction.
