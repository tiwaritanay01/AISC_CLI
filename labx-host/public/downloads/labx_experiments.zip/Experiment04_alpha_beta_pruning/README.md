# Experiment 04: Implementation of Alpha-Beta Pruning Algorithm

## Aim
To implement Minimax Search with Alpha-Beta Pruning for two-player adversarial games.

## Description
Adversarial search and branch pruning algorithm optimizing the minimax game-tree decision process.

## Theory
Alpha-Beta Pruning is a search algorithm used to reduce the number of nodes to be evaluated in a minimax tree, it considers two values alpha and beta which represent the best possible score for the maximizing player and the minimizing player respectively. The algorithm works by maintaining a window of possible scores, if the score of a node is outside this window it can be pruned, reducing the number of nodes to be evaluated. The alpha value is the best possible score for the maximizing player, while the beta value is the best possible score for the minimizing player, the algorithm prunes nodes that are guaranteed to have a score outside the alpha-beta window.
